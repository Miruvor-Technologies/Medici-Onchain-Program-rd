pub const MEDICI_SEED: &[u8] = b"medici";
pub const MEDICI_SCHOLARSHIP_PROGRAM_SEED: &[u8] = b"scholarship_program";
pub const FEES_CONFIGURATION_ACCOUNT_SEED: &[u8] = b"fees_configuration_account";
